/*
    Student Name: Stephanie Fraga
    File Name: script.js
    Date: 12-02-2023
*/

//jQuery for hero image to consume the header window space
$(document).ready(function() {
	$('.hero').height($(window).height());
});
